from django.shortcuts import render
from testapp.models import employeeadd,add
import sqlite3
from django.contrib import messages
from operator import itemgetter
import datetime

# Create your views here.
def index_view(request):
    return render(request,'testapp/index.html')


def adminlogin_view(request):
    con = sqlite3.connect("db.sqlite3")
    cursor=con.cursor()

    con2 = sqlite3.connect("db.sqlite3")
    cursor2=con2.cursor()

    sqlcommand = "select Employeeid from testapp_employeeadd"
    sqlcommand2 = "select Password from testapp_employeeadd"
    cursor.execute(sqlcommand)
    cursor2.execute(sqlcommand2)

    e=[]
    p=[]
    for i in cursor:
        e.append(i)
    for j in cursor2:
        p.append(j)

    res = list(map(itemgetter(0),e))
    res2 = list(map(itemgetter(0),p))
    print(res)

    if request.method=='POST':
        employeeid=request.POST['employeeid']
        Password=request.POST['Password']

        i=1
        k=len(res)
        while i<k:
            if res[i]==employeeid and res2[i]==Password:
                return render(request,'testapp/adminpage.html')
                break
            i+=1
        else:
            messages.info(request,"Check Username")

    return render(request,'testapp/adminlogin.html')

def employeelogin_view(request):
    con = sqlite3.connect("db.sqlite3")
    cursor=con.cursor()

    con2 = sqlite3.connect("db.sqlite3")
    cursor2=con2.cursor()

    sqlcommand = "select employeeid from testapp_employeeadd"
    sqlcommand2 = "select Password from testapp_employeeadd"
    cursor.execute(sqlcommand)
    cursor2.execute(sqlcommand2)

    e=[]
    p=[]
    for i in cursor:
        e.append(i)
    for j in cursor2:
        p.append(j)

    res = list(map(itemgetter(0),e))
    res2 = list(map(itemgetter(0),p))
    print(res)

    if request.method=='POST':
        employeeid=request.POST['employeeid']
        Password=request.POST['Password']

        i=1
        k=len(res)
        while i<k:
            if res[i]==employeeid and res2[i]==Password:
                return render(request,'testapp/employeepage.html')
                break
            i+=1
        else:
            messages.info(request,"Check Username")


    return render(request,'testapp/employeelogin.html')


def adminpage_view(request):
    return render(request,'testapp/adminpage.html')


def emploeepage_view(request):
    return render(request,'testapp/employeepage.html')


def inventory_view(request):
    date=datetime.datetime.now()
    add_list=add.objects.all()
    return render(request,'testapp/inventory.html',{'add_list':add_list,'insert_date':date})


def add_product_view(request):
    return render(request,'testapp/add_product.html')


def update_product_view(request):
    return render(request,'testapp/update_product.html')


def delete_product_view(request):
    return render(request,'testapp/delete_product.html')


def employee_view(request):
    date=datetime.datetime.now()
    employee_list=employeeadd.objects.all()
    return render(request,'testapp/employee.html',{'employee_list':employee_list,'insert_date':date})


def add_employee_view(request):
    return render(request,'testapp/add_employee.html')


def update_employee_view(request):
    return render(request,'testapp/update_employee.html')


def delete_employee_view(request):
    return render(request,'testapp/delete_employee.html')




def invoice_view(request):
    date=datetime.datetime.now()
    return render(request,'testapp/invoice.html',{'insert_date':date})
