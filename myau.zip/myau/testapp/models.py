from django.db import models

# Create your models here.
class employeeadd(models.Model):
    employeeid=models.CharField(max_length=130)
    employees_name=models.CharField(max_length=150)
    contact_no=models.IntegerField()
    address=models.CharField(max_length=150)
    adhar_no=models.IntegerField()
    Password=models.CharField(max_length=150)
    designation=models.CharField(max_length=150)

class add(models.Model):
    product_id=models.IntegerField()
    name=models.CharField(max_length=150)
    category=models.CharField(max_length=150)
    sub_category=models.CharField(max_length=150)
    in_stock=models.IntegerField()
    mrp=models.IntegerField()
