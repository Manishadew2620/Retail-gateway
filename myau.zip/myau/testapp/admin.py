from django.contrib import admin
from testapp.models import employeeadd,add
# Register your models here.

class employeeaddAdmin(admin.ModelAdmin):
    list_display=['employeeid','employee_name','contact_no','address','adhar_no','Password','designation']

class addAdmin(admin.ModelAdmin):
    list_display=['product_id','name','category','sub_category','in_stock','mrp']

admin.site.register(employeeadd)
admin.site.register(add)
